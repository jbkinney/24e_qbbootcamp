#!/usr/bin/env bash

# clean.sh
#
# Clean directories for new analysis

rm -rf mappings pileups scripts
rm -f genome/genome.fasta.*
rm -f bedfiles/*
rm -f *.sh.*
rm -f *~
