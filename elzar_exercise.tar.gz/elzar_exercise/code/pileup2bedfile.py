#!/usr/bin/env python
import sys
import os

# {{{ http://code.activestate.com/recipes/81611/ (r2)


def int_to_roman(input):
    """
    Convert an integer to Roman numerals.
    """
    if type(input) != type(1):
        raise TypeError
        print("expected integer, got %s" % type(input))
    if not 0 < input < 4000:
        raise ValueError
        print("Argument must be between 1 and 3999")
    ints = (1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1)
    nums = ('M', 'CM', 'D', 'CD', 'C', 'XC', 'L', 'XL', 'X', 'IX', 'V', 'IV',
            'I')
    result = ""
    for i in range(len(ints)):
        count = int(input / ints[i])
        result += nums[i] * count
        input -= ints[i] * count
    return result


def roman_to_int(input):
    """
    Convert a roman numeral to an integer.
    """
    if type(input) != type(""):
        raise TypeError
        print("expected string, got %s" % type(input))
    input = input.upper()
    nums = ['M', 'D', 'C', 'L', 'X', 'V', 'I']
    ints = [1000, 500, 100, 50, 10, 5, 1]
    places = []
    for c in input:
        if not c in nums:
            raise ValueError
            print("input is not a valid roman numeral: %s" % input)
    for i in range(len(input)):
        c = input[i]
        value = ints[nums.index(c)]
        # If the next place holds a larger number, this value is negative.
        try:
            nextvalue = ints[nums.index(input[i + 1])]
            if nextvalue > value:
                value *= -1
        except IndexError:
            # there is no next place.
            pass
        places.append(value)
    sum = 0
    for n in places:
        sum += n
    # Easiest test for validity...
    if int_to_roman(sum) == input:
        return sum
    else:
        raise ValueError
        print('input is not a valid roman numeral: %s' % input)


# end of http://code.activestate.com/recipes/81611/ }}}

# Get input file name from user
in_file_name = sys.argv[1]

# Set output file name
out_file_name = in_file_name + '.bed'

# Get name of samples
sample_name = os.path.basename(in_file_name).split('.')[0]

# Get read length from user
read_length = int(sys.argv[2])

# Open input file for reading
f = open(in_file_name)

# Open output file for writing
g = open(out_file_name, 'w')

# Write bedfile header to output file
g.write(
    'browser position chrIV:1-1531933\ntrack type=bedGraph visibility=2 name="%s" description="%s"\n'
    % (sample_name, sample_name))

# For each line in input file, determine chromosome, position, and number of overlapping reads,
# Every read_length positions, write chromosome, position, and num reads to file
# This is complicated by no-read positions not being recorded
current_chromosome = 'not set'
for l in f:
    atoms = l.strip().split()
    chromosome = int(atoms[0])
    position = int(atoms[1])
    num_reads = int(atoms[3])

    # Reset counts if new chromosome
    if chromosome != current_chromosome:
        k = 1
        current_chromosome = chromosome

    # Write positions
    if position % read_length == 0:

        # Catch up to current position
        while position > read_length * k:
            g.write('chr%s\t%d\t%d\t%d\t\n' %
                    (int_to_roman(chromosome),
                     (k - 1) * read_length + 1, k * read_length, 0))
            k += 1

        # Write read counts for current position
        g.write('chr%s\t%d\t%d\t%d\t\n' %
                (int_to_roman(chromosome), position - read_length + 1,
                 position, num_reads))
        k += 1
